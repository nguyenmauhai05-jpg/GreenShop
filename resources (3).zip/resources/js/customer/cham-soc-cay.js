document.addEventListener('DOMContentLoaded', () => {
    const page = document.getElementById('aiCarePage');
    const form = document.getElementById('plantChatForm');
    const input = document.getElementById('plantChatInput');
    const messages = document.getElementById('plantChatMessages');
    const submit = document.getElementById('plantChatSubmit');
    const conversationInput = document.getElementById('conversationId');
    const selectedPlant = document.getElementById('selectedPlant');
    const imageInput = document.getElementById('plantImageInput');
    const attachButton = document.getElementById('attachImageBtn');
    const previewBox = document.getElementById('imagePreviewBox');
    const previewImage = document.getElementById('imagePreview');
    const fileName = document.getElementById('imageFileName');
    const removeImage = document.getElementById('removeImageBtn');
    const chatUrl = page?.dataset.chatUrl;
    const baseUrl = page?.dataset.baseUrl;

    if (!form || !input || !messages || !submit || !conversationInput || !imageInput || !chatUrl || !baseUrl) return;

    const aiAvatarSvg = `
        <svg class="ai-icon" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M12 21V10"></path>
            <path d="M12 10C9 10 6 8 6 5c3 0 6 2 6 5Z"></path>
            <path d="M12 14c3 0 6-2 6-5-3 0-6 2-6 5Z"></path>
        </svg>`;

    const scrollBottom = () => { messages.scrollTop = messages.scrollHeight; };

    // Render basic Markdown safely (without injecting model-generated HTML).
    function renderReply(container, raw) {
        const text = String(raw || '').replace(/\r\n/g, '\n').trim()
            .replace(/\n[ \t]*\n(?:[ \t]*\n)+/g, '\n\n');
        const lines = text.split('\n');
        let list = null;
        const inline = (node, value) => {
            const parts = value.split(/(\*\*[^*]+\*\*)/g);
            parts.forEach(part => {
                if (part.startsWith('**') && part.endsWith('**')) {
                    const strong = document.createElement('strong');
                    strong.textContent = part.slice(2, -2);
                    node.appendChild(strong);
                } else node.appendChild(document.createTextNode(part));
            });
        };
        lines.forEach(line => {
            const trimmed = line.trim();
            if (!trimmed) { list = null; return; }
            const heading = trimmed.match(/^#{1,4}\s+(.+)$/);
            const item = trimmed.match(/^(?:[-*]\s+|\d+[.)]\s+)(.+)$/);
            if (heading) {
                list = null;
                const h = document.createElement('h4');
                inline(h, heading[1]);
                container.appendChild(h);
            } else if (item) {
                if (!list) { list = document.createElement('ul'); container.appendChild(list); }
                const li = document.createElement('li'); inline(li, item[1]); list.appendChild(li);
            } else {
                list = null;
                const p = document.createElement('p'); inline(p, trimmed); container.appendChild(p);
            }
        });
    }
    document.querySelectorAll('[data-ai-reply]').forEach(element => {
        const text = element.textContent;
        element.textContent = '';
        renderReply(element, text);
    });

    function addMessage(text, type, imageUrl = null) {
        const row = document.createElement('div');
        row.className = `chat-row ${type === 'user' ? 'chat-row-user' : 'chat-row-ai'}`;

        if (type === 'ai') {
            const avatar = document.createElement('div');
            avatar.className = 'message-ai-avatar';
            avatar.innerHTML = aiAvatarSvg;
            row.appendChild(avatar);
        }

        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${type === 'user' ? 'user-bubble' : 'ai-bubble'}`;
        if (imageUrl) {
            const img = document.createElement('img');
            img.src = imageUrl;
            img.className = 'chat-uploaded-image';
            img.alt = 'Ảnh cây';
            bubble.appendChild(img);
        }
        if (type === 'ai') {
            const content = document.createElement('div');
            content.className = 'ai-reply-content';
            renderReply(content, text);
            bubble.appendChild(content);
        } else {
            const paragraph = document.createElement('p');
            paragraph.textContent = text;
            bubble.appendChild(paragraph);
        }

        const time = document.createElement('div');
        time.className = type === 'user' ? 'message-meta' : 'message-footer';
        time.textContent = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
        bubble.appendChild(time);
        row.appendChild(bubble);
        messages.appendChild(row);
        scrollBottom();
    }

    if (attachButton) attachButton.addEventListener('click', () => imageInput.click());

    imageInput.addEventListener('change', function () {
        const file = this.files[0];
        if (!file) return;
        const allowed = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowed.includes(file.type)) { alert('Chỉ hỗ trợ JPG, PNG hoặc WEBP.'); this.value = ''; return; }
        if (file.size > 5 * 1024 * 1024) { alert('Ảnh không được vượt quá 5MB.'); this.value = ''; return; }
        if (!previewImage || !fileName || !previewBox) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            previewImage.src = event.target.result;
            fileName.textContent = file.name;
            previewBox.hidden = false;
        };
        reader.readAsDataURL(file);
    });

    if (removeImage) removeImage.addEventListener('click', () => {
        imageInput.value = '';
        if (previewImage) previewImage.src = '';
        if (previewBox) previewBox.hidden = true;
    });

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const message = input.value.trim();
        if (!message) return;
        const selectedFile = imageInput.files[0] || null;
        const localImageUrl = selectedFile ? URL.createObjectURL(selectedFile) : null;
        addMessage(message, 'user', localImageUrl);
        submit.disabled = true;

        const formData = new FormData();
        formData.append('message', message);
        if (conversationInput.value) formData.append('cuoc_tro_chuyen_id', conversationInput.value);
        if (selectedPlant?.value) formData.append('plant_id', selectedPlant.value);
        if (selectedFile) formData.append('anh', selectedFile);

        try {
            const token = form.querySelector('input[name="_token"]')?.value || '';
            const response = await fetch(chatUrl, {
                method: 'POST',
                headers: { Accept: 'application/json', 'X-CSRF-TOKEN': token },
                body: formData,
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Không thể gửi câu hỏi.');

            conversationInput.value = data.cuoc_tro_chuyen_id;
            addMessage(data.reply, 'ai');
            input.value = '';
            imageInput.value = '';
            if (previewImage) previewImage.src = '';
            if (previewBox) previewBox.hidden = true;

            const currentConversation = new URLSearchParams(window.location.search).get('conversation');
            if (!currentConversation && data.cuoc_tro_chuyen_id) {
                window.setTimeout(() => {
                    window.location.href = `${baseUrl}?conversation=${data.cuoc_tro_chuyen_id}`;
                }, 300);
            }
        } catch (error) {
            console.error(error);
            addMessage(error.message || 'Đã xảy ra lỗi. Vui lòng thử lại.', 'ai');
        } finally {
            submit.disabled = false;
            input.focus();
            if (localImageUrl) URL.revokeObjectURL(localImageUrl);
        }
    });

    input.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            form.requestSubmit();
        }
    });

    scrollBottom();
});
