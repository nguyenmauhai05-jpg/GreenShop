document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('ratingInput');
    const picker = document.querySelector('[data-star-picker]');
    const label = document.getElementById('starLabel');
    const labels = ['', 'Rất không hài lòng', 'Không hài lòng', 'Bình thường', 'Hài lòng', 'Rất hài lòng'];

    if (picker && input) {
        const buttons = [...picker.querySelectorAll('[data-star]')];
        const paint = (value) => {
            buttons.forEach((button) => {
                const active = Number(button.dataset.star) <= value;
                button.textContent = active ? '★' : '☆';
                button.classList.toggle('active', active);
            });
            if (label) label.textContent = value ? labels[value] : 'Chọn điểm đánh giá';
        };
        buttons.forEach((button) => button.addEventListener('click', () => {
            input.value = button.dataset.star;
            paint(Number(button.dataset.star));
        }));
        paint(Number(input.value || 0));
    }

    const textarea = document.getElementById('noi_dung');
    const charCount = document.getElementById('reviewCharCount');
    if (textarea && charCount) {
        textarea.addEventListener('input', () => charCount.textContent = textarea.value.length);
    }

    const imageInput = document.getElementById('reviewImages');
    const preview = document.getElementById('imagePreviewList');
    const counter = document.getElementById('imageUploadCounter');

    if (imageInput && preview) {
        const MAX_IMAGES = 5;
        const MAX_SIZE = 5 * 1024 * 1024;
        const ALLOWED_TYPES = ['image/jpeg', 'image/png'];

        const resetImages = (message) => {
            alert(message);
            imageInput.value = '';
            preview.innerHTML = '';
            if (counter) counter.textContent = 'Đã chọn 0/5 ảnh';
        };

        imageInput.addEventListener('change', () => {
            preview.innerHTML = '';
            const files = [...imageInput.files];

            if (files.length > MAX_IMAGES) {
                resetImages('Bạn chỉ được tải lên tối đa 5 ảnh.');
                return;
            }

            const invalidType = files.find(file => !ALLOWED_TYPES.includes(file.type));
            if (invalidType) {
                resetImages('Chỉ chấp nhận ảnh JPG, JPEG hoặc PNG.');
                return;
            }

            const oversized = files.find(file => file.size > MAX_SIZE);
            if (oversized) {
                resetImages('Mỗi ảnh không được vượt quá 5MB.');
                return;
            }

            if (counter) counter.textContent = `Đã chọn ${files.length}/5 ảnh`;

            files.forEach((file, index) => {
                const wrapper = document.createElement('div');
                wrapper.className = 'review-image-preview-item';

                const image = document.createElement('img');
                image.alt = `Ảnh đánh giá ${index + 1}`;
                image.src = URL.createObjectURL(file);
                image.onload = () => URL.revokeObjectURL(image.src);

                wrapper.appendChild(image);
                preview.appendChild(wrapper);
            });
        });
    }
});
