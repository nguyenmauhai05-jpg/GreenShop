@php
    $footerLogo = \App\Support\GreenShopSettings::get('logo', 'images/logo.png');
    $footerBrandName = \App\Support\GreenShopSettings::get('store_name', 'GreenShop');
@endphp

<footer class="site-footer">

    <div class="footer-container">

        {{-- =================================================
             PHẦN TRÊN
        ================================================== --}}
        <div class="footer-top">

            {{-- THƯƠNG HIỆU --}}
            <div class="footer-brand">

                <a href="{{ route('trang-chu') }}" class="footer-logo" aria-label="GreenShop">
                    <span class="footer-logo-image">
                        <img
                            src="{{ asset($footerLogo) }}"
                            alt="{{ $footerBrandName }}"
                        >
                    </span>
                    <span class="footer-brand-name">{{ $footerBrandName }}</span>
                </a>

                <p class="footer-description">
                    Mang cây xanh khỏe mạnh và vẻ đẹp tự nhiên
                    đến từng không gian sống.
                </p>

                <div class="footer-socials">

                    <a href="#" aria-label="Facebook">
                        f
                    </a>

                    <a href="#" aria-label="Instagram">
                        ◎
                    </a>

                    <a href="#" aria-label="TikTok">
                        ♪
                    </a>

                </div>

            </div>


            {{-- CỬA HÀNG --}}
            <div class="footer-column">

                <h4>
                    CỬA HÀNG
                </h4>

                <a href="#">
                    Cây trong nhà
                </a>

                <a href="#">
                    Cây ngoài trời
                </a>

                <a href="#">
                    Sản phẩm mới
                </a>

                <a href="#">
                    Sản phẩm bán chạy
                </a>

            </div>


            {{-- DỊCH VỤ --}}
            <div class="footer-column">

                <h4>
                    DỊCH VỤ
                </h4>

                <a href="#">
                    Chăm sóc cây
                </a>

                <a href="#">
                    Hướng dẫn chăm sóc
                </a>

                <a href="#">
                    Liên hệ
                </a>

                <a href="#">
                    Câu hỏi thường gặp
                </a>

            </div>


            {{-- GREENSHOP --}}
            <div class="footer-column">

                <h4>
                    VỀ GREENSHOP
                </h4>

                <a href="#">
                    Giới thiệu
                </a>

                <a href="#">
                    Bài viết
                </a>

                <a href="#">
                    Cửa hàng
                </a>

                <a href="#">
                    Chính sách
                </a>

            </div>

        </div>


        {{-- =================================================
             PHẦN DƯỚI
        ================================================== --}}
        <div class="footer-bottom">

            <p>
                © {{ date('Y') }} GreenShop. All rights reserved.
            </p>

            <div class="footer-bottom-links">

                <a href="#">
                    Chính sách bảo mật
                </a>

                <a href="#">
                    Điều khoản sử dụng
                </a>

            </div>

        </div>

    </div>

</footer>

