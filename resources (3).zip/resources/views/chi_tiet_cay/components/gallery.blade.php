@php
    $anh = $cay->anh_dai_dien;

    if ($anh) {

        $anh = ltrim($anh, '/');

        if (!str_starts_with($anh, 'images/')) {
            $anh = 'images/trang-chu/products/' . $anh;
        }

        $anhUrl = asset($anh);

    } else {
        $anhUrl = null;
    }
@endphp


<div class="gallery">

    <div class="main-gallery">

        @if($anhUrl)

            <img
                src="{{ $anhUrl }}"
                alt="{{ $cay->ten_cay }}"
            >

        @else

            <div class="product-no-image">
                🌱
            </div>

        @endif


        <button
            type="button"
            class="gallery-nav gallery-prev"
        >
            ‹
        </button>


        <button
            type="button"
            class="gallery-nav gallery-next"
        >
            ›
        </button>

    </div>


    <div class="thumb-list">

        <button
            type="button"
            class="thumb-item active"
        >

            @if($anhUrl)

                <img
                    src="{{ $anhUrl }}"
                    alt="{{ $cay->ten_cay }}"
                >

            @else

                🌱

            @endif

        </button>

    </div>

</div>