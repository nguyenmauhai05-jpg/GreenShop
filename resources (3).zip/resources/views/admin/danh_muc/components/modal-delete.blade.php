<div
    id="deleteCategoryModal"
    class="category-modal"
>

    <div
        class="category-modal-backdrop"
        onclick="closeDeleteCategoryModal()"
    ></div>


    <div class="category-modal-dialog category-delete-dialog">

        <div class="category-delete-icon">
            !
        </div>


        <h3>
            Xóa danh mục
        </h3>


        <p>
            Bạn có chắc chắn muốn xóa danh mục
            <strong id="deleteCategoryName"></strong>
            không?
        </p>


        <p class="category-delete-note">
            Danh mục đang chứa cây sẽ không thể xóa.
            Bạn cần chuyển các cây sang danh mục khác trước.
        </p>


        <form
            id="deleteCategoryForm"
            method="POST"
            action=""
        >
            @csrf
            @method('DELETE')


            <div class="category-modal-actions">

                <button
                    type="button"
                    class="category-btn-cancel"
                    onclick="closeDeleteCategoryModal()"
                >
                    Hủy bỏ
                </button>


                <button
                    type="submit"
                    class="category-btn-delete"
                >
                    Xóa danh mục
                </button>

            </div>

        </form>

    </div>

</div>