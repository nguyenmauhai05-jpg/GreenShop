<header class="admin-header">

    <div class="admin-header-left">

        <button
            type="button"
            class="admin-menu-toggle"
        >
            ☰
        </button>

        <h1>
            @yield('page-title', 'Dashboard')
        </h1>

    </div>


    <div class="admin-header-right">

        {{-- SEARCH --}}
        <div class="admin-header-search">

            <span>⌕</span>

            <input
                type="text"
                placeholder="Tìm kiếm nhanh..."
            >

        </div>



    </div>

</header>