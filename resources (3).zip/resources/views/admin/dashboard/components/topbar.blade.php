    {{-- =====================================================
        CHÀO MỪNG + LỌC THỜI GIAN
    ====================================================== --}}

    <div class="dashboard-topbar">

        <div class="dashboard-welcome">

            <h2>
                Chào mừng trở lại,
                {{ Auth::user()->ho_ten ?? 'Quản trị viên' }}! 👋
            </h2>

            <p>
                Tổng quan tình hình hoạt động của GreenShop.
            </p>

        </div>


        <form
            method="GET"
            action="{{ route('admin.dashboard') }}"
            class="dashboard-date-filter"
        >

            <span class="dashboard-filter-icon">
                <svg
                    viewBox="0 0 24 24"
                    width="18"
                    height="18"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="1.8"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    aria-hidden="true"
                >
                    <rect x="4" y="5" width="16" height="15" rx="2"/>
                    <path d="M8 3v4"/>
                    <path d="M16 3v4"/>
                    <path d="M4 10h16"/>
                </svg>
            </span>

            <input
                type="date"
                name="tu_ngay"
                value="{{ request('tu_ngay', isset($tuNgay) ? $tuNgay->format('Y-m-d') : '') }}"
            >

            <span>-</span>

            <input
                type="date"
                name="den_ngay"
                value="{{ request('den_ngay', isset($denNgay) ? $denNgay->format('Y-m-d') : '') }}"
            >

            <button type="submit">
                Lọc
            </button>

        </form>

    </div>
