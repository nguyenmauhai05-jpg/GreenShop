<x-pagination :paginator="$cayCanhs" />
